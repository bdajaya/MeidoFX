package id.alphareso.meidofx;

import javafx.application.Application;

public class MainApp {

  public static void main(String[] args) {
    Application.launch(BaseTest.class,args);
  }
}
