package id.alphareso.meidofx.base.stages;

import javafx.geometry.Rectangle2D;
import javafx.stage.Screen;

/**
 * ScreenPositioner membantu menghitung posisi dan ukuran bagian layar utama,
 * seperti setengah atau seperempat bagian layar.
 */
public class ScreenPositioner {

    private final Rectangle2D screenBounds;

    public ScreenPositioner() {
        this.screenBounds = Screen.getPrimary().getVisualBounds();
    }

    public Rectangle2D getFullScreen() {
        return screenBounds;
    }

    public Rectangle2D getLeftHalf() {
        return new Rectangle2D(
                0,
                0,
                screenBounds.getWidth() / 2,
                screenBounds.getHeight()
        );
    }

    public Rectangle2D getRightHalf() {
        return new Rectangle2D(
                screenBounds.getWidth() / 2 + 1,
                0,
                screenBounds.getWidth() / 2,
                screenBounds.getHeight()
        );
    }

    public Rectangle2D getTopLeftQuarter() {
        return new Rectangle2D(
                0,
                0,
                screenBounds.getWidth() / 2,
                screenBounds.getHeight() / 2
        );
    }

    public Rectangle2D getTopRightQuarter() {
        return new Rectangle2D(
                screenBounds.getWidth() / 2 + 1,
                0,
                screenBounds.getWidth() / 2,
                screenBounds.getHeight() / 2
        );
    }

    public Rectangle2D getBottomLeftQuarter() {
        return new Rectangle2D(
                0,
                screenBounds.getHeight() / 2 + 1,
                screenBounds.getWidth() / 2,
                screenBounds.getHeight() / 2
        );
    }

    public Rectangle2D getBottomRightQuarter() {
        return new Rectangle2D(
                screenBounds.getWidth() / 2 + 1,
                screenBounds.getHeight() / 2 + 1,
                screenBounds.getWidth() / 2,
                screenBounds.getHeight() / 2
        );
    }
}

