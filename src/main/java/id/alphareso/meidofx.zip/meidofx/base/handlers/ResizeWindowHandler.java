package id.alphareso.meidofx.base.handlers;

import id.alphareso.meidofx.base.stages.BaseStage;

public class ResizeWindowHandler {

    private final BaseStage baseStage;

    public ResizeWindowHandler(BaseStage baseStage) {
        this.baseStage = baseStage;
    }

    /**
     * Menangani perubahan ukuran stage, memastikan bahwa saat resize,
     * ukuran baru dipertahankan, dan tidak melebihi batas layar.
     */
    public void handleResize(double width, double height) {
        // Mencegah ukuran melebihi batas layar
        double maxWidth = baseStage.getScreenBounds().getWidth();
        double maxHeight = baseStage.getScreenBounds().getHeight();

        // Update ukuran jendela
        if (width <= maxWidth && height <= maxHeight) {
            baseStage.setWidth(width);
            baseStage.setHeight(height);
        }
    }

    /**
     * Menangani toggle untuk custom maximization, mengubah ukuran stage sesuai dengan
     * kondisi maximized.
     */
    public void handleMaximizeToggle(boolean isMaximized) {
        baseStage.toggleCustomMaximized(isMaximized);
    }

    /**
     * Menangani toggle untuk fullscreen
     */
    public void handleFullScreenToggle(boolean isFullscreen) {
        baseStage.toggleFullScreen(isFullscreen);
    }
}
