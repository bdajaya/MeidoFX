package id.alphareso.meidofx.base.stages;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.geometry.BoundingBox;
import javafx.geometry.Rectangle2D;
import javafx.scene.input.MouseEvent;
import javafx.stage.Screen;
import javafx.stage.Stage;

/**
 * BaseStage adalah subclass Stage yang menyediakan fitur tambahan:
 * - Custom maximization (tanpa menggunakan Stage.setMaximized)
 * - Toggle fullscreen yang bisa di-observe
 * - Posisi ke bagian tertentu dari layar utama
 */
public class BaseStage extends Stage {

    //#region Properties

    private final SimpleBooleanProperty customMaximized = new SimpleBooleanProperty(false);
    private final SimpleBooleanProperty fullScreenToggled = new SimpleBooleanProperty(false);
    private final SimpleBooleanProperty fittingScreen = new SimpleBooleanProperty(false);

    private BoundingBox previousBounds;
    private BoundingBox maximizedBounds;

    private final ScreenPositioner positioner = new ScreenPositioner();

    private boolean isSnappingInProgress = false; // Tambahkan flag di luar method

    private double dragAnchorX;  // Variabel untuk menyimpan posisi X saat mouse ditekan
    private double dragAnchorY;  // Variabel untuk menyimpan posisi Y saat mouse ditekan

    //#endregion

    //#region Constructor

    public BaseStage() {
        super();

        fullScreenToggled.addListener((obs, oldVal, isFullscreen) -> super.setFullScreen(isFullscreen));

        customMaximized.addListener((obs, oldVal, isMaximized) -> {
            if (isMaximized) {
                saveCurrentBoundsAsPrevious();
                Rectangle2D screenArea = positioner.getFullScreen();
                maximizedBounds = new BoundingBox(
                        screenArea.getMinX(), screenArea.getMinY(),
                        screenArea.getWidth(), screenArea.getHeight()
                );
                applyBounds(maximizedBounds);
                fittingScreen.set(true);
            } else if (previousBounds != null) {
                applyBounds(previousBounds);
                fittingScreen.set(false);
            }
        });
    }

    //#endregion

    //#region Public API - State Setters

    public void toggleCustomMaximized(boolean value) {
        this.customMaximized.set(value);
    }

    public void toggleFullScreen(boolean value) {
        this.fullScreenToggled.set(value);
    }

    public void toggleFitScreen(boolean value) {
        this.fittingScreen.set(value);
    }

    public void restoreToScreenPosition(double centerX, double topY) {
        if (isCustomMaximized()) toggleCustomMaximized(false);
        if (previousBounds != null) {
            setWidth(previousBounds.getWidth());
            setHeight(previousBounds.getHeight());
        }
        setX(centerX - getWidth() / 2);
        setY(topY);
        fittingScreen.set(false);
    }

    //#endregion

    //#region Public API - Positioning Methods

    public void moveToLeftScreen() {
        moveAndResizeTo(positioner.getLeftHalf());
    }

    public void moveToRightScreen() {
        if (isCustomMaximized()) return;
        moveAndResizeTo(positioner.getRightHalf());
    }

    public void moveToTopLeftScreen() {
        if (isCustomMaximized()) return;
        moveAndResizeTo(positioner.getTopLeftQuarter());
    }

    public void moveToTopRightScreen() {
        moveAndResizeTo(positioner.getTopRightQuarter());
    }

    public void moveToBottomLeftScreen() {
        moveAndResizeTo(positioner.getBottomLeftQuarter());
    }

    public void moveToBottomRightScreen() {
        moveAndResizeTo(positioner.getBottomRightQuarter());
    }

    //#endregion

    //#region Private Helpers

    private void saveCurrentBoundsAsPrevious() {
        previousBounds = new BoundingBox(getX(), getY(), getWidth(), getHeight());
    }

    private void moveAndResizeTo(Rectangle2D area) {
        saveCurrentBoundsAsPrevious();
        applyBounds(new BoundingBox(area.getMinX(), area.getMinY(), area.getWidth(), area.getHeight()));
        fittingScreen.set(true);
    }

    private void applyBounds(BoundingBox box) {
        setX(box.getMinX());
        setY(box.getMinY());
        setWidth(box.getWidth());
        setHeight(box.getHeight());
    }

    //#endregion

    //#region Getters & Property Accessors

    public boolean isCustomMaximized() {
        return customMaximized.get();
    }

    public SimpleBooleanProperty customMaximizedProperty() {
        return customMaximized;
    }

    public boolean isFullScreenToggled() {
        return fullScreenToggled.get();
    }

    public SimpleBooleanProperty fullScreenToggledProperty() {
        return fullScreenToggled;
    }

    public boolean isFittingScreen() {
        return fittingScreen.get();
    }

    public SimpleBooleanProperty fittingScreenProperty() {
        return fittingScreen;
    }

    public void setDragAnchor(double x, double y) {
        this.dragAnchorX = x;
        this.dragAnchorY = y;
    }

    public double getDragAnchorX() {
        return dragAnchorX;
    }

    public double getDragAnchorY() {
        return dragAnchorY;
    }

    //#endregion

    /**
     * Mendapatkan bounds dari layar tempat stage berada.
     * @return Rectangle2D yang menggambarkan ukuran dan posisi layar
     */
    public Rectangle2D getScreenBounds() {
        return Screen.getPrimary().getVisualBounds();
    }

    /**
     * Menangani peristiwa mousePressed untuk menangkap posisi awal drag.
     */
    public void handleMousePressed(MouseEvent event) {
        // Menyimpan posisi awal saat mouse ditekan
        dragAnchorX = event.getScreenX() - getX();
        dragAnchorY = event.getScreenY() - getY();
    }

    /**
     * Menangani peristiwa mouseDragged untuk menggeser jendela.
     * Jika kursor mencapai tepi layar, jendela akan menjadi vertikal half screen.
     */
    public void handleMouseDragged(MouseEvent event) {
        if (isSnappingInProgress) {
            // Abaikan event drag jika snapping sedang diproses (dari event drag sebelumnya)
            // Atau mungkin reset flag di sini jika snapping selesai? Tergantung implementasi snapping
            // Cara terbaik adalah membiarkan drag terhenti sampai mouse dilepas/ditekan lagi.
            return; // Penting: Langsung keluar jika snapping terjadi di iterasi sebelumnya
        }

        double offsetX = event.getScreenX() - dragAnchorX;
        double offsetY = event.getScreenY() - dragAnchorY;

        // Cek kondisi snapping TERLEBIH DAHULU
        if (isNearLeftScreen(event.getScreenX())) {
            // Set flag sebelum memanggil moveTo...Screen
            isSnappingInProgress = true;
            moveToLeftScreen();
            // Setelah snap, jangan lakukan setX/setY dari drag di iterasi ini
            // Biarkan event mouseReleased atau mousePressed berikutnya mereset drag
            // Option: Anda mungkin perlu mereset dragAnchor jika ingin drag berlanjut dari posisi snap
            // Tapi biasanya lebih clean jika user perlu melepas & menekan mouse lagi.

        } else if (isNearRightScreen(event.getScreenX())) {
            // Set flag sebelum memanggil moveTo...Screen
            isSnappingInProgress = true;
            moveToRightScreen();
            // Setelah snap, jangan lakukan setX/setY dari drag di iterasi ini
        } else {
            // Jika TIDAK snapping, baru terapkan posisi drag
            setX(offsetX);
            setY(offsetY);
            // Pastikan flag isSnappingInProgress direset jika diperlukan
            // Reset flag mungkin lebih baik di handleMouseReleased
        }
    }

    public void handleMouseReleased(MouseEvent event) {
        // Reset flag snapping saat mouse dilepas
        isSnappingInProgress = false;
        // Lakukan hal lain yang mungkin perlu dilakukan saat drag berakhir
    }

    /**
     * Memeriksa apakah kursor berada di tepi kiri layar.
     */
    private boolean isNearLeftScreen(double screenX) {
        return screenX < 50; // Misalnya, jika kursor lebih dekat dari 50px dari kiri layar
    }

    /**
     * Memeriksa apakah kursor berada di tepi kanan layar.
     */
    private boolean isNearRightScreen(double screenX) {
        return screenX > getScreenBounds().getWidth() - 50; // Tepi kanan layar
    }
}

