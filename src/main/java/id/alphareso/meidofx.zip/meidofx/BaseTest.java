package id.alphareso.meidofx;

import id.alphareso.meidofx.base.handlers.ResizeWindowHandler;
import id.alphareso.meidofx.base.stages.BaseStage;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent; // Import MouseEvent
import javafx.stage.Stage;
import javafx.scene.layout.VBox; // Sesuaikan dengan root pane Anda

public class BaseTest extends Application {

  private double dragAnchorX; // Pindahkan variabel dragAnchorX ke sini atau ke handler terpisah
  private double dragAnchorY; // Pindahkan variabel dragAnchorY ke sini atau ke handler terpisah

  // Atau, lebih baik lagi, gunakan method handler di BaseStage langsung

  public static void main(String[] args) {
    launch(args);
  }

  @Override
  public void start(Stage primaryStage) {
    // Buat BaseStage Anda
    BaseStage baseStage = new BaseStage();
    // baseStage.initStyle(StageStyle.UNDECORATED); // Jika Anda ingin jendela tanpa dekorasi

    ResizeWindowHandler resizeHandler = new ResizeWindowHandler(baseStage);

    // Buat UI
    Button toggleMaximizeButton = new Button("Toggle Maximize");
    Button toggleFullscreenButton = new Button("Toggle Fullscreen");

    toggleMaximizeButton.setOnAction(e -> resizeHandler.handleMaximizeToggle(!baseStage.isCustomMaximized()));
    toggleFullscreenButton.setOnAction(e -> resizeHandler.handleFullScreenToggle(!baseStage.isFullScreenToggled()));

    // Layout - Ini akan menjadi root pane
    VBox layout = new VBox(10, toggleMaximizeButton, toggleFullscreenButton);
    Scene scene = new Scene(layout, 300, 200);

    baseStage.setScene(scene);
    baseStage.setTitle("BaseStage Interaction");

    // ================================================================
    // === PASANG EVENT HANDLER DRAG PADA ROOT PANE ATAU SCENE ===
    // ================================================================

    // Method Reference ke handler di BaseStage
    // Gunakan event handler yang ada di BaseStage langsung

    // Listener untuk MOUSE_PRESSED
    layout.setOnMousePressed(baseStage::handleMousePressed);
    // Atau jika Anda mau, Anda bisa membuat handler di sini dan memanggil method BaseStage
    /*
    layout.setOnMousePressed(event -> {
         // Simpan anchor di sini atau panggil method di BaseStage
         // baseStage.setDragAnchor(event.getScreenX() - baseStage.getX(), event.getScreenY() - baseStage.getY());
         baseStage.handleMousePressed(event); // Panggil handler di BaseStage
    });
    */

    // Listener untuk MOUSE_DRAGGED
    layout.setOnMouseDragged(baseStage::handleMouseDragged);
     /*
    layout.setOnMouseDragged(event -> {
         // Lakukan perhitungan drag dan set posisi stage
         // double offsetX = event.getScreenX() - baseStage.getDragAnchorX();
         // double offsetY = event.getScreenY() - baseStage.getDragAnchorY();
         // baseStage.setX(offsetX);
         // baseStage.setY(offsetY);
         // Atau panggil handler di BaseStage yang sudah ada logika drag & snapping
         baseStage.handleMouseDragged(event); // Panggil handler di BaseStage
    });
    */

    // Listener untuk MOUSE_RELEASED
    layout.setOnMouseReleased(baseStage::handleMouseReleased);
     /*
    layout.setOnMouseReleased(event -> {
         // Reset state drag/snapping
         baseStage.handleMouseReleased(event); // Panggil handler di BaseStage
    });
    */


    // Simulasi Resize Stage (Listener ini tampaknya untuk tujuan testing)
    // Ini mungkin menyebabkan ResizeWindowHandler.handleResize dipanggil saat Anda drag jendela
    // yang juga mengubah ukuran. Perlu diperhatikan jika ada konflik.
    // Tapi untuk masalah drag awal, fokus pada event mouse.
    baseStage.widthProperty().addListener((obs, oldWidth, newWidth) -> {
      // HATI-HATI: Mengubah ukuran jendela saat drag bisa menyebabkan masalah
      // Mungkin listener resize ini hanya untuk user resizing (manual dari border)
      // Jika ini mengganggu drag, nonaktifkan sementara saat drag berlangsung
      resizeHandler.handleResize(newWidth.doubleValue(), baseStage.getHeight());
    });
    baseStage.heightProperty().addListener((obs, oldHeight, newHeight) -> {
      // HATI-HATI: Mengubah ukuran jendela saat drag bisa menyebabkan masalah
      resizeHandler.handleResize(baseStage.getWidth(), newHeight.doubleValue());
    });


    baseStage.show();
  }
}